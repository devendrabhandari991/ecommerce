package ecommerce.response;

public class OrderInfo {

	private String invertoryId;

	private String accountId;

	private String msg;

	public String getInvertoryId() {
		return invertoryId;
	}

	public void setInvertoryId(String invertoryId) {
		this.invertoryId = invertoryId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
