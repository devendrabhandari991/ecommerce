package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.service.OrderService;

import ecommerce.response.OrderInfo;

@RestController
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	@PostMapping("/order/create")
	public String createOrder(@RequestBody OrderInfo orderInfo) {
		try {
			orderService.createOrder(orderInfo);
		} catch (RuntimeException ex) {
			throw ex;
		}
		return orderInfo.getMsg();
	}
}
