package com.ecommerce.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.ecommerce.model.Inventory;
import com.ecommerce.model.Orders;
import com.ecommerce.repository.InventoryRepository;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.service.OrderService;

import ecommerce.response.OrderInfo;

public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	InventoryRepository inventoryRepository;
	
	@Override
	public OrderInfo createOrder(OrderInfo orderInfo) {
		if(orderInfo != null){
			Inventory inventory = inventoryRepository.findByInventoryId(orderInfo.getInvertoryId());
			if(inventory != null && inventory.isExists()){
				Orders orders = new Orders();
				orders.setAccountId(orderInfo.getAccountId());
				orders.setInventoryId(inventory.getInventoryId());
				orderRepository.save(orders);
				orderInfo.setMsg("Order Placed Successfully");
			} else {
				orderInfo.setMsg("Product is out of Stock");
			}
		}
		return orderInfo;
	}

	
	
}
