package com.ecommerce.service;

import ecommerce.response.OrderInfo;

public interface OrderService {

	OrderInfo createOrder(OrderInfo orderInfo);
	
}
